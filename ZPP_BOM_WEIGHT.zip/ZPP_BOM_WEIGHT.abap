*&---------------------------------------------------------------------*
*& Report ZPP_BOM_WEIGHT
*& WRICEF 194 - BOM Net Weight (all BOM levels)
*&---------------------------------------------------------------------*
REPORT zpp_bom_weight.

TABLES: mara, marc.

TYPES: BEGIN OF ty_out,
         matnr  TYPE mara-matnr,             "Material
         werks  TYPE marc-werks,             "Plant
         bmeng  TYPE stko-bmeng,             "Base qty
         bmein  TYPE stko-bmein,             "Base UOM
         matkl  TYPE mara-matkl,             "Material group
         maktx  TYPE makt-maktx,             "Description
         mtart  TYPE mara-mtart,             "Material type
         weight TYPE p LENGTH 13 DECIMALS 3, "Net weight
         idnrk  TYPE stpo-idnrk,             "Component
         menge  TYPE stpo-menge,             "Component qty
         meins  TYPE stpo-meins,             "Component UOM
         cmtart TYPE mara-mtart,             "Component mat. type
         hrkft  TYPE mbew-hrkft,             "Origin group
         hrktx  TYPE tkkh2-hrktx,            "Origin group text
       END OF ty_out.

TYPES: BEGIN OF ty_bom,
         matnr TYPE mast-matnr,
         werks TYPE mast-werks,
         stlal TYPE mast-stlal,
         stlnr TYPE mast-stlnr,
         bmeng TYPE stko-bmeng,
         bmein TYPE stko-bmein,
       END OF ty_bom.

DATA: gt_bom        TYPE TABLE OF ty_bom,
      gt_comp       TYPE TABLE OF ty_out,   "raw components of current BOM
      gt_out        TYPE TABLE OF ty_out,   "table shown in the ALV
      gt_out_detail TYPE TABLE OF ty_out.   "full detail, kept for drill-down

*&---------------------------------------------------------------------*
*& FS: "if user click on material, above data must be reflect"
*&---------------------------------------------------------------------*
CLASS lcl_alv_handler DEFINITION.
  PUBLIC SECTION.
    CLASS-METHODS on_double_click
      FOR EVENT double_click OF cl_salv_events_table
      IMPORTING row column.
ENDCLASS.

CLASS lcl_alv_handler IMPLEMENTATION.
  METHOD on_double_click.

    DATA: ls_sum    TYPE ty_out,
          ls_det    TYPE ty_out,
          lt_detail TYPE TABLE OF ty_out,
          lo_alv    TYPE REF TO cl_salv_table.

    READ TABLE gt_out INTO ls_sum INDEX row.
    CHECK sy-subrc = 0.

    LOOP AT gt_out_detail INTO ls_det
         WHERE matnr = ls_sum-matnr
           AND werks = ls_sum-werks.
      APPEND ls_det TO lt_detail.
    ENDLOOP.

    CHECK lt_detail IS NOT INITIAL.

    TRY.
        cl_salv_table=>factory(
          IMPORTING r_salv_table = lo_alv
          CHANGING  t_table      = lt_detail ).

        lo_alv->get_columns( )->set_optimize( abap_true ).
        lo_alv->get_functions( )->set_all( abap_true ).
        lo_alv->set_screen_popup( start_column = 5  end_column = 160
                                  start_line   = 3  end_line   = 25 ).
        lo_alv->display( ).
      CATCH cx_salv_msg.
    ENDTRY.

  ENDMETHOD.
ENDCLASS.

*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
SELECT-OPTIONS: s_matnr FOR mara-matnr OBLIGATORY,
                s_werks FOR marc-werks OBLIGATORY.
PARAMETERS:     p_act   AS CHECKBOX DEFAULT 'X',            "Active BOM
                p_det   RADIOBUTTON GROUP r1 DEFAULT 'X',   "Detailed BOM
                p_sum   RADIOBUTTON GROUP r1.               "Summarized BOM
SELECTION-SCREEN END OF BLOCK b1.

*&---------------------------------------------------------------------*
START-OF-SELECTION.

  PERFORM get_boms.
  PERFORM build_data.
  PERFORM display.

*&---------------------------------------------------------------------*
*& Valid BOMs
*&   MAST  = material -> BOM link            (I_BILLOFMATERIALITEMTP)
*&   STKO  = BOM header / status / base qty  (I_BILLOFMATERIAL)
*&   STLAN = '1'   -> Production BOM usage   (FS hardcode)
*&   LOEKZ = space -> not archived for deletion
*&   STLST = '1'/'0' -> Active BOM checkbox
*&---------------------------------------------------------------------*
FORM get_boms.

  DATA lv_stlst TYPE stko-stlst.

  IF p_act = abap_true.
    lv_stlst = '1'.          "Active BOM ticked
  ELSE.
    lv_stlst = '0'.          "not ticked
  ENDIF.

  SELECT m~matnr m~werks m~stlal m~stlnr k~bmeng k~bmein
    FROM mast AS m
    INNER JOIN stko AS k ON  k~stlnr = m~stlnr
                         AND k~stlal = m~stlal
    INTO TABLE gt_bom
   WHERE m~matnr IN s_matnr
     AND m~werks IN s_werks
     AND m~stlan = '1'
     AND k~stlst = lv_stlst
     AND k~loekz = space.

  IF gt_bom IS INITIAL.
    MESSAGE 'No BOM found for the given selection' TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*& Header info + explode + net duplicates + weight + origin group
*&---------------------------------------------------------------------*
FORM build_data.

  DATA: ls_bom  TYPE ty_bom,
        ls_out  TYPE ty_out,
        ls_comp TYPE ty_out,
        lv_sum  TYPE p LENGTH 13 DECIMALS 3,
        lv_hit  TYPE abap_bool.

  LOOP AT gt_bom INTO ls_bom.

    CLEAR ls_out.
    ls_out-matnr = ls_bom-matnr.
    ls_out-werks = ls_bom-werks.
    ls_out-bmeng = COND #( WHEN ls_bom-bmeng = 0 THEN 1 ELSE ls_bom-bmeng ).
    ls_out-bmein = ls_bom-bmein.

    "FS: Material Group + Material Type from I_PRODUCT (= MARA)
    SELECT SINGLE matkl mtart FROM mara
      INTO (ls_out-matkl, ls_out-mtart)
     WHERE matnr = ls_bom-matnr.

    "FS: Description from I_PRODUCTTEXT (= MAKT) for LANGUAGE = E
    SELECT SINGLE maktx FROM makt
      INTO ls_out-maktx
     WHERE matnr = ls_bom-matnr
       AND spras = 'E'.

    "FS: component details via RCS13001 engine (CS_BOM_EXPL_MAT_V2)
    CLEAR gt_comp.
    PERFORM explode USING ls_bom-matnr ls_bom-werks ls_bom-stlal ls_out-bmeng.

    "FS: "add or subtract where component has duplicate value" -> COLLECT
    "MATNR/WERKS are part of the key so components of different top
    "materials never merge with each other.
    LOOP AT gt_comp INTO ls_comp.
      ls_comp-matnr = ls_bom-matnr.
      ls_comp-werks = ls_bom-werks.
      CLEAR: ls_comp-bmeng, ls_comp-bmein, ls_comp-matkl, ls_comp-maktx,
             ls_comp-mtart, ls_comp-weight, ls_comp-hrkft, ls_comp-hrktx.
      COLLECT ls_comp INTO gt_out.
    ENDLOOP.

    "FS: Weight = sum of component qty / base qty.
    "HALB/FERT excluded from the sum: their own components are already
    "counted (multi-level explosion), so counting the HALB/FERT line too
    "would double count. Agreed deviation from the FS - documented in UT.
    CLEAR lv_sum.
    LOOP AT gt_out INTO ls_comp
         WHERE matnr  = ls_bom-matnr
           AND werks  = ls_bom-werks
           AND cmtart <> 'HALB'
           AND cmtart <> 'FERT'.
      lv_sum = lv_sum + ls_comp-menge.
    ENDLOOP.
    ls_out-weight = lv_sum / ls_out-bmeng.

    "stamp header fields + origin group onto this material's rows
    CLEAR lv_hit.
    LOOP AT gt_out INTO ls_comp
         WHERE matnr = ls_bom-matnr
           AND werks = ls_bom-werks.

      lv_hit = abap_true.

      ls_comp-bmeng  = ls_out-bmeng.
      ls_comp-bmein  = ls_out-bmein.
      ls_comp-matkl  = ls_out-matkl.
      ls_comp-maktx  = ls_out-maktx.
      ls_comp-mtart  = ls_out-mtart.
      ls_comp-weight = ls_out-weight.

      "FS: Origin Group -> MBEW-HRKFT (BWKEY = plant, BWTAR = blank)
      SELECT SINGLE hrkft FROM mbew
        INTO ls_comp-hrkft
       WHERE matnr = ls_comp-idnrk
         AND bwkey = ls_out-werks
         AND bwtar = space.

      "FS: HRKFT -> TKKH2-HRKTX
      IF ls_comp-hrkft IS NOT INITIAL.
        SELECT SINGLE hrktx FROM tkkh2
          INTO ls_comp-hrktx
         WHERE hrkft = ls_comp-hrkft.
      ENDIF.

      MODIFY gt_out FROM ls_comp.
    ENDLOOP.

    "BOM without any valid component -> still show its header line
    IF lv_hit = abap_false.
      APPEND ls_out TO gt_out.
    ENDIF.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*& Multi-level explosion + component filter (recursive for cross-plant)
*&---------------------------------------------------------------------*
FORM explode USING iv_matnr TYPE mara-matnr
                   iv_werks TYPE marc-werks
                   iv_stlal TYPE stko-stlal
                   iv_menge TYPE stko-bmeng.

  DATA: lt_stb   TYPE STANDARD TABLE OF stpox,
        ls_stb   TYPE stpox,
        ls_comp  TYPE ty_out,
        lv_plant TYPE marc-werks,
        lv_alt   TYPE stko-stlal,
        lt_plant TYPE TABLE OF marc-werks.

  CALL FUNCTION 'CS_BOM_EXPL_MAT_V2'
    EXPORTING
      capid  = 'PP01'          "FS: Application  = PP01 (hardcode)
      datuv  = sy-datum
      mehrs  = 'X'             "multi-level = all BOM levels
      mtnrv  = iv_matnr
      werks  = iv_werks
      stlal  = iv_stlal
      stlan  = '1'             "FS: BOM Usage = 1 (hardcode)
      emeng  = iv_menge        "FS: Required Qty = Base Qty
    TABLES
      stb    = lt_stb
    EXCEPTIONS
      OTHERS = 1.

  CHECK sy-subrc = 0.

  LOOP AT lt_stb INTO ls_stb.

    "FS: keep only ROH / HALB / FERT / ZSCR, with sub-rules
    CASE ls_stb-mtart.

      WHEN 'ROH'.
        "ROH: only if UOM is EA or KG
        CHECK ls_stb-meins = 'EA' OR ls_stb-meins = 'KG'.

      WHEN 'ZSCR'.
        "ZSCR: only if material starts with SC or RP
        CHECK ls_stb-idnrk(2) = 'SC' OR ls_stb-idnrk(2) = 'RP'.

      WHEN 'HALB' OR 'FERT'.
        "FS Business Req 4: BOM may sit in another plant.
        "MBEW: BWKEY = screen plant, BWTAR <> screen plant, take 1st row
        CLEAR: lv_plant, lv_alt, lt_plant.

        SELECT bwtar
          FROM mbew
          INTO TABLE lt_plant
          UP TO 1 ROWS
         WHERE matnr =  ls_stb-idnrk
           AND bwkey =  iv_werks
           AND bwtar <> iv_werks
           AND bwtar <> space
         ORDER BY bwtar ASCENDING.

        READ TABLE lt_plant INTO lv_plant INDEX 1.

        IF sy-subrc = 0 AND lv_plant IS NOT INITIAL.
          SELECT SINGLE stlal FROM mast
            INTO lv_alt
           WHERE matnr = ls_stb-idnrk
             AND werks = lv_plant
             AND stlan = '1'.
          IF sy-subrc = 0.
            "same logic again -> recursion
            PERFORM explode USING ls_stb-idnrk lv_plant lv_alt ls_stb-menge.
          ENDIF.
        ENDIF.

      WHEN OTHERS.
        CONTINUE.              "VERP etc -> not wanted
    ENDCASE.

    "HALB/FERT are shown in the list (FS) but excluded from the weight
    "sum in BUILD_DATA to avoid double counting.
    CLEAR ls_comp.
    ls_comp-idnrk  = ls_stb-idnrk.
    ls_comp-menge  = ls_stb-menge.
    ls_comp-meins  = ls_stb-meins.
    ls_comp-cmtart = ls_stb-mtart.
    APPEND ls_comp TO gt_comp.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*& Radio 1 = Detailed BOM, Radio 2 = Summarized BOM (+ drill-down)
*&---------------------------------------------------------------------*
FORM display.

  TYPES: BEGIN OF ty_lbl,
           fname TYPE lvc_fname,
           short TYPE scrtext_s,
           med   TYPE scrtext_m,
           long  TYPE scrtext_l,
         END OF ty_lbl.

  DATA: lo_alv    TYPE REF TO cl_salv_table,
        lo_cols   TYPE REF TO cl_salv_columns_table,
        lo_col    TYPE REF TO cl_salv_column,
        lo_events TYPE REF TO cl_salv_events_table,
        ls_sum    TYPE ty_out,
        ls_lbl    TYPE ty_lbl,
        lt_lbl    TYPE TABLE OF ty_lbl.

  "keep the full detail before the summarized view collapses GT_OUT
  SORT gt_out BY matnr werks idnrk.
  gt_out_detail = gt_out.

  IF p_sum = abap_true.
    "Summarized: blank the component fields, one row per material/plant
    LOOP AT gt_out INTO ls_sum.
      CLEAR: ls_sum-idnrk, ls_sum-menge, ls_sum-meins,
             ls_sum-cmtart, ls_sum-hrkft, ls_sum-hrktx.
      MODIFY gt_out FROM ls_sum.
    ENDLOOP.
    DELETE ADJACENT DUPLICATES FROM gt_out COMPARING matnr werks.
  ENDIF.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_alv
        CHANGING  t_table      = gt_out ).
    CATCH cx_salv_msg.
      RETURN.
  ENDTRY.

  lo_cols = lo_alv->get_columns( ).

  "column headings
  lt_lbl = VALUE #(
    ( fname = 'MATNR'  short = 'Material'  med = 'Material'        long = 'Material Code' )
    ( fname = 'WERKS'  short = 'Plant'     med = 'Plant'           long = 'Plant' )
    ( fname = 'BMENG'  short = 'Base Qty'  med = 'Base Quantity'   long = 'BOM Base Quantity' )
    ( fname = 'BMEIN'  short = 'Base UoM'  med = 'Base UoM'        long = 'Base Unit of Measure' )
    ( fname = 'MATKL'  short = 'Matl Grp'  med = 'Material Group'  long = 'Material Group' )
    ( fname = 'MAKTX'  short = 'Descr.'    med = 'Description'     long = 'Material Description' )
    ( fname = 'MTART'  short = 'Mat.Type'  med = 'Material Type'   long = 'Material Type' )
    ( fname = 'WEIGHT' short = 'Net Wt'    med = 'Net Weight'      long = 'BOM Net Weight' )
    ( fname = 'IDNRK'  short = 'Component' med = 'Component'       long = 'Component Material' )
    ( fname = 'MENGE'  short = 'Comp.Qty'  med = 'Component Qty'   long = 'Component Quantity' )
    ( fname = 'MEINS'  short = 'Comp.UoM'  med = 'Component UoM'   long = 'Component Unit' )
    ( fname = 'CMTART' short = 'Comp.Type' med = 'Comp Mat Type'   long = 'Component Material Type' )
    ( fname = 'HRKFT'  short = 'Orig.Grp'  med = 'Origin Group'    long = 'Origin Group' )
    ( fname = 'HRKTX'  short = 'Orig.Text' med = 'Origin Grp Text' long = 'Origin Group Description' ) ).

  LOOP AT lt_lbl INTO ls_lbl.
    TRY.
        lo_col = lo_cols->get_column( ls_lbl-fname ).
        lo_col->set_short_text(  ls_lbl-short ).
        lo_col->set_medium_text( ls_lbl-med ).
        lo_col->set_long_text(   ls_lbl-long ).
      CATCH cx_salv_not_found.
    ENDTRY.
  ENDLOOP.

  "optimize AFTER the headings, so widths fit the new texts
  lo_cols->set_optimize( abap_true ).

  lo_alv->get_functions( )->set_all( abap_true ).

  IF p_sum = abap_true.

    "hide the component columns in the summarized view
    LOOP AT VALUE stringtab( ( `IDNRK` ) ( `MENGE` ) ( `MEINS` )
                            ( `CMTART` ) ( `HRKFT` ) ( `HRKTX` ) )
         INTO DATA(lv_fname).
      TRY.
          lo_col = lo_cols->get_column( CONV #( lv_fname ) ).
          lo_col->set_technical( abap_true ).
        CATCH cx_salv_not_found.
      ENDTRY.
    ENDLOOP.

    "FS: double-click a material -> show its detailed components
    lo_events = lo_alv->get_event( ).
    SET HANDLER lcl_alv_handler=>on_double_click FOR lo_events.

    "the handler reads GT_OUT by INDEX; an active ALV filter would make
    "the displayed row number differ from the physical index, so filter
    "is switched off in the summarized view only.
    lo_alv->get_functions( )->set_filter( abap_false ).

  ENDIF.

  lo_alv->display( ).

ENDFORM.
